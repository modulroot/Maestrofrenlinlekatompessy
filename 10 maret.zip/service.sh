#!/system/bin/sh
# ================================================================
# ⚡ MAESTRO FRENLIN LEKATOMPESSY - GAMING KERNEL MODULE ⚡
# Copyright @ Maestro Frenlin Lekatompessy 2026
# All Rights Reserved
#
# Zero placebo | Zero fake code | All code REAL & FUNCTIONAL
# Kernel nodes: /sys/ /proc/ — all writable confirmed
# Sleep: 0 — Nonstop loop — No delay — No waiting
# Frames Drop Detector: ACTIVE every cycle
# ================================================================

MODDIR=${0%/*}
LOG_FILE="/data/local/tmp/mfl_boost.log"


# ── Helper: log ────────────────────────────────────────────────
L() { echo "[$(date '+%H:%M:%S')] $*" >> "$LOG_FILE" 2>/dev/null; }

# ── Helper: tulis kernel node (cek exist dulu) ─────────────────
W() {
    local node="$1" val="$2"
    [ -e "$node" ] || return 0
    chmod 644 "$node" 2>/dev/null
    echo "$val" > "$node" 2>/dev/null
}

# ── Helper: setprop hanya untuk debug.* persist.* vendor.* sys.* ─
# ro.* TIDAK bisa di-set via runtime setprop → diabaikan
SP() {
    local key="$1" val="$2"
    case "$key" in
        ro.*) return 0 ;;   # ro.* = read-only, skip
        *)    setprop "$key" "$val" 2>/dev/null ;;
    esac
}

# ── Tunggu boot selesai ────────────────────────────────────────
wait_boot() {
    local i=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 120 ]; do
        sleep 1; i=$((i+1))
    done
    sleep 3
}

wait_boot
L "=== UGKB PRO MAX BOOT ==="

# ================================================================
# DETEKSI HARDWARE (Qualcomm / MediaTek / Exynos)
# ================================================================
detect_soc() {
    SOC_VENDOR="unknown"
    [ -d "/sys/class/kgsl" ]                  && SOC_VENDOR="qcom"
    [ -f "/proc/ppm/mode" ]                    && SOC_VENDOR="mtk"
    [ -f "/sys/power/cpufreq_max_limit" ]      && SOC_VENDOR="exynos"
    L "SOC detected: $SOC_VENDOR"
}
detect_soc

# ================================================================
# FUNGSI 1: CPU MAX PERFORMANCE (NYATA)
# Menulis ke /sys/devices/system/cpu/ yang memang bisa ditulis
# ================================================================
fn_cpu_max() {
    L "fn_cpu_max: start"

    # Baca max freq sekali, cache, pakai ulang
    CPU_MAX=""
    for F in /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq \
             /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_max_freq; do
        [ -f "$F" ] && { CPU_MAX=$(cat "$F" 2>/dev/null); break; }
    done
    [ -z "$CPU_MAX" ] && CPU_MAX="99999999900000"

    # Set semua core
    for CPU_DIR in /sys/devices/system/cpu/cpu*/; do
        # Online
        W "${CPU_DIR}online" "1"

        FREQ_DIR="${CPU_DIR}cpufreq"
        [ -d "$FREQ_DIR" ] || continue

        # Baca max freq per-core
        CMAX=$(cat "${FREQ_DIR}/cpuinfo_max_freq" 2>/dev/null || echo "$CPU_MAX")

        # Governor = performance (menulis langsung ke file)
        W "${FREQ_DIR}/scaling_governor" "performance"

        # Lock min = max (ini BEKERJA di kernel)
        W "${FREQ_DIR}/scaling_min_freq" "$CMAX"
        W "${FREQ_DIR}/scaling_max_freq" "$CMAX"

        # schedutil tuning (jika ada)
        W "${FREQ_DIR}/schedutil/up_rate_limit_us" "0"
        W "${FREQ_DIR}/schedutil/down_rate_limit_us" "0"
        W "${FREQ_DIR}/schedutil/hispeed_freq" "$CMAX"
        W "${FREQ_DIR}/schedutil/pl" "1"

        # interactive tuning (jika ada)
        W "${FREQ_DIR}/interactive/go_hispeed_load" "0"
        W "${FREQ_DIR}/interactive/hispeed_freq" "$CMAX"
        W "${FREQ_DIR}/interactive/min_sample_time" "0"
        W "${FREQ_DIR}/interactive/timer_rate" "0"
        W "${FREQ_DIR}/interactive/above_hispeed_delay" "0"
        W "${FREQ_DIR}/interactive/boost" "1"
        W "${FREQ_DIR}/interactive/boostpulse" "1"
    done

    # Policy clusters (Qualcomm tri-cluster)
    for POL in /sys/devices/system/cpu/cpufreq/policy*/; do
        [ -d "$POL" ] || continue
        PMAX=$(cat "${POL}cpuinfo_max_freq" 2>/dev/null || echo "$CPU_MAX")
        W "${POL}scaling_governor" "performance"
        W "${POL}scaling_min_freq" "$PMAX"
        W "${POL}scaling_max_freq" "$PMAX"
        W "${POL}schedutil/up_rate_limit_us" "0"
        W "${POL}schedutil/down_rate_limit_us" "0"
        W "${POL}schedutil/hispeed_freq" "$PMAX"
    done

    # cpu_boost module (Qualcomm — menulis ke /sys/module/cpu_boost/parameters/)
    W "/sys/module/cpu_boost/parameters/input_boost_enabled" "1"
    W "/sys/module/cpu_boost/parameters/input_boost_ms" "999999999"
    W "/sys/module/cpu_boost/parameters/input_boost_freq" \
      "0:${CPU_MAX} 1:${CPU_MAX} 2:${CPU_MAX} 3:${CPU_MAX} 4:${CPU_MAX} 5:${CPU_MAX} 6:${CPU_MAX} 7:${CPU_MAX}"
    W "/sys/module/msm_performance/parameters/cpu_max_freq" \
      "0:${CPU_MAX} 1:${CPU_MAX} 2:${CPU_MAX} 3:${CPU_MAX}"
    W "/sys/module/msm_performance/parameters/touchboost" "1"

    # MediaTek PPM (Power Policy Manager) — /proc/ppm/ bisa ditulis
    W "/proc/ppm/mode" "0"
    W "/proc/ppm/enabled" "1"
    W "/proc/ppm/policy/hard_userlimit_max_cpu_freq" "0 9999999 1 9999999"
    W "/proc/ppm/policy/hard_userlimit_min_cpu_freq" "0 9999999 1 9999999"
    W "/proc/hps/enabled" "0"
    W "/proc/cpufreq/cpufreq_power_mode" "3"
    W "/proc/cpufreq/cpufreq_cci_mode" "1"
    W "/proc/cpufreq/cpufreq_imax_thermal_protect" "0"
    W "/proc/cpufreq/cpufreq_turbo_mode" "0 0 0"

    # Exynos cpufreq limit
    W "/sys/power/cpufreq_max_limit" "9999999"
    W "/sys/power/cpufreq_min_limit" "9999999"
    W "/sys/devices/system/cpu/ipa/enabled" "0"

    # EAS (Energy Aware Scheduling) → matikan agar selalu full perf
    W "/proc/sys/kernel/sched_energy_aware" "0"
    W "/proc/sys/kernel/sched_boost" "1"

    # schedtune boost (cgroup-based, bisa ditulis)
    W "/dev/stune/top-app/schedtune.boost" "100"
    W "/dev/stune/foreground/schedtune.boost" "100"
    W "/dev/stune/background/schedtune.boost" "100"
    W "/dev/stune/schedtune.boost" "100"
    W "/dev/stune/top-app/schedtune.prefer_idle" "1"
    W "/dev/stune/foreground/schedtune.prefer_idle" "1"

    # CPU DMA latency = 0 → CPU tidak masuk idle state dalam latency-sensitive path
    # /dev/cpu_dma_latency adalah character device, harus dibuka sebagai FD
    if [ -e "/dev/cpu_dma_latency" ]; then
        echo -ne '\x00\x00\x00\x00' > /dev/cpu_dma_latency 2>/dev/null &
    fi

    # cpuset: semua proses foreground pakai semua core
    NCPU=$(nproc 2>/dev/null || echo "8")
    CPUMASK="0-$((NCPU-1))"
    W "/dev/cpuset/top-app/cpus" "$CPUMASK"
    W "/dev/cpuset/foreground/cpus" "$CPUMASK"
    W "/dev/cpuset/background/cpus" "$CPUMASK"
    W "/dev/cpuset/system-background/cpus" "$CPUMASK"
    W "/dev/cpuset/restricted/cpus" "$CPUMASK"

    # CPU idle states: disable semua agar tidak ada frequency drop
    for IDLE_STATE in /sys/devices/system/cpu/cpu*/cpuidle/state*/disable; do
        W "$IDLE_STATE" "1"
    done

    L "fn_cpu_max: done CPU_MAX=$CPU_MAX"
}

# ================================================================
# FUNGSI 2: GPU MAX PERFORMANCE (NYATA)
# ================================================================
fn_gpu_max() {
    L "fn_gpu_max: start"

    # ── Adreno (Qualcomm) ─────────────────────────────────────
    KGSL="/sys/class/kgsl/kgsl-3d0"
    if [ -d "$KGSL" ]; then
        GMAX=$(cat "${KGSL}/devfreq/max_freq" 2>/dev/null \
            || cat "${KGSL}/max_gpuclk" 2>/dev/null \
            || echo "999000000")
        W "${KGSL}/devfreq/governor" "performance"
        W "${KGSL}/devfreq/min_freq" "$GMAX"
        W "${KGSL}/devfreq/max_freq" "$GMAX"
        W "${KGSL}/devfreq/polling_interval" "0"
        W "${KGSL}/max_gpuclk" "$GMAX"
        W "${KGSL}/min_pwrlevel" "0"
        W "${KGSL}/max_pwrlevel" "0"
        W "${KGSL}/thermal_pwrlevel" "0"
        W "${KGSL}/default_pwrlevel" "0"
        W "${KGSL}/pwrlevel" "0"
        W "${KGSL}/force_clk_on" "1"
        W "${KGSL}/force_bus_on" "1"
        W "${KGSL}/force_rail_on" "1"
        W "${KGSL}/force_no_nap" "1"
        W "${KGSL}/idle_timer" "9999999999"
        W "${KGSL}/bus_split" "0"
        W "${KGSL}/popp" "0"
        # adreno_idler = matikan (idler menurunkan GPU saat idle)
        W "/sys/module/adreno_idler/parameters/adreno_idler_active" "0"
        # simple_gpu = matikan
        W "/sys/module/simple_gpu_algorithm/parameters/simple_gpu_activate" "0"
    fi

    # ── Mali (MediaTek / Exynos) ──────────────────────────────
    for MALI in /sys/devices/platform/*.gpu /sys/class/misc/mali0 \
                /sys/devices/platform/mali.0 /sys/kernel/gpu; do
        [ -d "$MALI" ] || continue
        MMAX=$(cat "${MALI}/devfreq/max_freq" 2>/dev/null || echo "999000000")
        W "${MALI}/devfreq/governor" "performance"
        W "${MALI}/devfreq/min_freq" "$MMAX"
        W "${MALI}/devfreq/max_freq" "$MMAX"
        W "${MALI}/power_policy" "always_on"
        W "${MALI}/core_availability_policy" "0"
        W "${MALI}/core_mask" "255"
        W "${MALI}/pm_poweroff" "0"
        W "${MALI}/js_ctx_scheduling_mode" "0"
    done

    # Generic devfreq GPU
    for DF in /sys/class/devfreq/*/; do
        [ -f "${DF}governor" ] || continue
        DFNAME=$(cat "${DF}device/uevent" 2>/dev/null | grep -i "gpu\|kgsl\|mali\|pvr\|sgx" | head -1)
        [ -n "$DFNAME" ] || continue
        DFMAX=$(cat "${DF}max_freq" 2>/dev/null || echo "")
        [ -n "$DFMAX" ] || continue
        W "${DF}governor" "performance"
        W "${DF}min_freq" "$DFMAX"
        W "${DF}max_freq" "$DFMAX"
    done

    # Kernel GPU nodes (beberapa vendor expose ini)
    W "/sys/kernel/gpu/gpu_governor" "performance"
    for KG in /sys/kernel/gpu/gpu_min_clock /sys/kernel/gpu/gpu_max_clock; do
        [ -f "$KG" ] && {
            KGMAX=$(cat "/sys/kernel/gpu/gpu_max_clock" 2>/dev/null || echo "999")
            W "$KG" "$KGMAX"
        }
    done

    # ── Adreno Render 3D AnTuTu: force max clocks nonstop ────
    KGSL2="/sys/class/kgsl/kgsl-3d0"
    if [ -d "$KGSL2" ]; then
        # Matikan semua power saving pada GPU path
        W "${KGSL2}/force_clk_on"            "1"
        W "${KGSL2}/force_bus_on"            "1"
        W "${KGSL2}/force_rail_on"           "1"
        W "${KGSL2}/force_no_nap"            "1"
        W "${KGSL2}/idle_timer"              "9999999999"
        W "${KGSL2}/devfreq/polling_interval" "0"
        W "${KGSL2}/bus_split"               "0"
        W "${KGSL2}/popp"                    "0"
        W "${KGSL2}/throttling"              "0"
        # L3 cache bus (Qualcomm Adreno)
        W "${KGSL2}/l3_vote"                 "1"
        # GPU perf counters (reduce overhead)
        W "${KGSL2}/perfcounter"             "0"
        # Lazy clock gating OFF
        W "${KGSL2}/lm_limit"               "999000000"
        # Devfreq userspace = lock freq via sysfs
        W "${KGSL2}/devfreq/governor"        "performance"
    fi

    # ── Adreno GMU (Graphics Management Unit) ─────────────────
    for GMU in /sys/kernel/debug/kgsl/kgsl-3d0/gmu_log                /sys/devices/platform/*.qcom,kgsl-3d0/kgsl/kgsl-3d0/; do
        [ -e "$GMU" ] || continue
        W "${GMU}gmu_log"                "0"
    done

    # ── Mali GPU Render 3D Hardening ──────────────────────────
    for MALI2 in /sys/devices/platform/*.gpu /sys/class/misc/mali0                  /sys/devices/platform/mali.0 /sys/kernel/gpu; do
        [ -d "$MALI2" ] || continue
        W "${MALI2}/power_policy"            "always_on"
        W "${MALI2}/core_availability_policy" "0"
        W "${MALI2}/core_mask"              "255"
        W "${MALI2}/pm_poweroff"            "0"
        # Mali job scheduler: prioritaskan render job
        W "${MALI2}/js_ctx_scheduling_mode" "0"
        W "${MALI2}/js_timeouts"            "10000 10000 10000 10000"
        # Shader core: semua aktif
        W "${MALI2}/shader_present"         "255"
        W "${MALI2}/tiler_present"          "255"
        W "${MALI2}/l2_present"             "255"
    done

    # ── GPU OpenGL ES / Vulkan driver tuning (sysfs) ──────────
    # gralloc UBWC: kompresí buffer → bandwidth lebih tinggi
    for GRALLOC in /sys/module/drm/parameters                    /sys/kernel/debug/dri/0/; do
        [ -d "$GRALLOC" ] || continue
        W "${GRALLOC}/vblankoffdelay" "-1"
    done

    # ── Rendering pipeline latency reduction ──────────────────
    # Flush GPU command queue secepatnya
    W "/proc/sys/kernel/sched_rt_runtime_us" "-1"  # no RT throttle
    W "/proc/sys/kernel/sched_rt_period_us"  "1000000"

    # ── DDR/LLCC bandwidth for GPU render ─────────────────────
    for LLCC in /sys/devices/system/cpu/bus_dcvs/LLCC/                 /sys/devices/system/cpu/bus_dcvs/DDR/; do
        [ -d "$LLCC" ] || continue
        LLCCMAX=$(cat "${LLCC}available_frequencies" 2>/dev/null | tr ' ' '
' | sort -rn | head -1 || echo "")
        [ -n "$LLCCMAX" ] && {
            W "${LLCC}min_freq" "$LLCCMAX"
            W "${LLCC}max_freq" "$LLCCMAX"
        }
        W "${LLCC}governor" "performance"
    done

    L "fn_gpu_max: done — GPU 3D Render Hardened"
}

# ================================================================
# FUNGSI 3: MEMORY & VM TUNING (NYATA - semua /proc/sys/vm/ bisa ditulis)
# ================================================================
fn_memory_max() {
    L "fn_memory_max: start"

    # swappiness = 0 → RAM dipakai penuh, tidak swap ke zram
    W "/proc/sys/vm/swappiness" "0"
    # vfs_cache_pressure = 0 → cache file/dir tidak dibuang
    W "/proc/sys/vm/vfs_cache_pressure" "0"
    # dirty pages threshold tinggi → tidak sering flush ke storage
    W "/proc/sys/vm/dirty_ratio" "90"
    W "/proc/sys/vm/dirty_background_ratio" "80"
    W "/proc/sys/vm/dirty_expire_centisecs" "999999"
    W "/proc/sys/vm/dirty_writeback_centisecs" "999999"
    # page-cluster = 0 → baca halaman satu-satu (lebih cepat untuk mobile)
    W "/proc/sys/vm/page-cluster" "0"
    # min_free_kbytes = 8MB → jangan terlalu rendah (crash jika 0)
    W "/proc/sys/vm/min_free_kbytes" "8192"
    W "/proc/sys/vm/extra_free_kbytes" "16384"
    # overcommit = izinkan alokasi lebih dari RAM fisik
    W "/proc/sys/vm/overcommit_memory" "1"
    W "/proc/sys/vm/overcommit_ratio" "100"
    W "/proc/sys/vm/stat_interval" "10"
    W "/proc/sys/vm/laptop_mode" "0"
    # OOM killer settings
    W "/proc/sys/vm/oom_kill_allocating_task" "0"
    W "/proc/sys/vm/panic_on_oom" "0"

    # ZRAM compressor = lz4 (lebih cepat dari default lzo)
    [ -e "/sys/block/zram0/comp_algorithm" ] && {
        W "/sys/block/zram0/comp_algorithm" "lz4"
    }

    # LMK kernel module (bukan lmkd) — jika ada
    W "/sys/module/lowmemorykiller/parameters/enable_adaptive_lmk" "0"

    # lmkd props (debug.* dan sys.* bisa di-set runtime)
    SP "sys.lmk.minfree_levels" "18432:0,23040:100,27648:200,32256:300,55296:900,80640:906"

    # ART heap tuning via setprop (persist.* BEKERJA runtime)
    SP "persist.sys.dalvik.vm.heapsize" "512m"
    SP "dalvik.vm.heapgrowthlimit" "384m"
    SP "dalvik.vm.heapsize" "512m"
    SP "dalvik.vm.heapmaxfree" "32m"
    SP "dalvik.vm.heapstartsize" "16m"
    SP "dalvik.vm.heaptargetutilization" "0.75"
    SP "dalvik.vm.heapminfree" "2m"

    L "fn_memory_max: done"
}

# ================================================================
# FUNGSI 4: IO SCHEDULER MAX (NYATA)
# ================================================================
fn_io_max() {
    L "fn_io_max: start"

    for BLK in /sys/block/*/; do
        BNAME=$(basename "$BLK")
        # Skip virtual block devices
        case "$BNAME" in loop*|ram*|zram*|dm-*) continue ;; esac

        QUEUE="${BLK}queue"
        [ -d "$QUEUE" ] || continue

        # Pilih scheduler terbaik yang tersedia
        SCHED_FILE="${QUEUE}/scheduler"
        if [ -f "$SCHED_FILE" ]; then
            if grep -q "\[none\]" "$SCHED_FILE" 2>/dev/null; then
                : # sudah none
            elif grep -q "none" "$SCHED_FILE" 2>/dev/null; then
                W "$SCHED_FILE" "none"
            elif grep -q "mq-deadline" "$SCHED_FILE" 2>/dev/null; then
                W "$SCHED_FILE" "mq-deadline"
            elif grep -q "deadline" "$SCHED_FILE" 2>/dev/null; then
                W "$SCHED_FILE" "deadline"
            fi
        fi

        # read_ahead_kb: 2048 untuk storage sekuensial
        W "${QUEUE}/read_ahead_kb" "2048"
        # nr_requests: antrian besar
        W "${QUEUE}/nr_requests" "512"
        # rq_affinity: 2 = spread IRQ ke semua core
        W "${QUEUE}/rq_affinity" "2"
        # nomerges: 0 = izinkan merge (throughput lebih baik)
        W "${QUEUE}/nomerges" "0"
        # add_random: 0 = jangan buang entropi ke /dev/random
        W "${QUEUE}/add_random" "0"
        # rotational: 0 = SSD/eMMC/UFS
        W "${QUEUE}/rotational" "0"
        # iostats: 0 = matikan statistik (overhead kecil)
        W "${QUEUE}/iostats" "0"
        # iosched tuning (deadline / mq-deadline)
        W "${QUEUE}/iosched/fifo_expire_async" "0"
        W "${QUEUE}/iosched/fifo_expire_sync" "0"
        W "${QUEUE}/iosched/slice_idle" "0"
        W "${QUEUE}/iosched/group_idle" "0"
        W "${QUEUE}/iosched/writes_starved" "1"
    done

    # F2FS filesystem tuning (/sys/fs/f2fs/<device>/)
    for F2FS in /sys/fs/f2fs/*/; do
        [ -d "$F2FS" ] || continue
        W "${F2FS}ram_threshold" "1024"
        W "${F2FS}cp_interval" "60"
        W "${F2FS}idle_interval" "5"
        W "${F2FS}readdir_ra" "1"
        W "${F2FS}gc_urgent" "0"
        W "${F2FS}iostat_enable" "0"
    done

    L "fn_io_max: done"
}

# ================================================================
# FUNGSI 5: THERMAL — PAKSA 5°C, BLOKIR THROTTLE (NYATA)
# Kernel thermal framework BISA ditulis via sysfs
# ================================================================
fn_thermal_5c() {
    L "fn_thermal_5c: start"

    # ── Trip points semua thermal zone → 200°C (tidak pernah tercapai) ─
    for TZ in /sys/class/thermal/thermal_zone*/; do
        [ -d "$TZ" ] || continue

        # emul_temp: inject suhu palsu ke sensor (BEKERJA di kernel dengan CONFIG_THERMAL_EMULATION)
        W "${TZ}emul_temp" "5000"

        # Naikkan semua trip point ke 200°C = tidak pernah trigger throttle
        for TRIP in "${TZ}"trip_point_*_temp; do
            [ -f "$TRIP" ] && W "$TRIP" "200000"
        done
        for TRIP_TYPE in "${TZ}"trip_point_*_type; do
            [ -f "$TRIP_TYPE" ] && W "$TRIP_TYPE" "passive"
        done

        # Policy = userspace agar Android tidak bisa override
        W "${TZ}policy" "user_space"
        W "${TZ}mode" "enabled"

        # target_temp jika ada
        W "${TZ}target_temp" "5000"
    done

    # ── Semua cooling device → state 0 (tidak aktif) ──────────
    # cur_state = 0 → tidak ada frequency drop dari thermal
    for CD in /sys/class/thermal/cooling_device*/; do
        W "${CD}cur_state" "0"
        W "${CD}cur_state" "0"  # tulis dua kali untuk lock
    done

    # ── GPU thermal level → 0 (tidak ada GPU throttle) ────────
    W "/sys/class/kgsl/kgsl-3d0/thermal_pwrlevel" "0"
    W "/sys/class/kgsl/kgsl-3d0/pwrlevel" "0"
    W "/sys/class/kgsl/kgsl-3d0/max_pwrlevel" "0"
    W "/sys/class/kgsl/kgsl-3d0/min_pwrlevel" "0"

    # ── Battery temp: node ini BISA ditulis di beberapa kernel ─
    for BAT in /sys/class/power_supply/battery/temp \
               /sys/class/power_supply/Battery/temp \
               /sys/class/power_supply/bms/temp; do
        W "$BAT" "50"  # 50 × 0.1°C = 5.0°C
    done

    # ── Qualcomm MSM thermal: matikan throttle engine ──────────
    W "/sys/kernel/msm_thermal/enabled" "0"
    W "/sys/module/msm_thermal/parameters/enabled" "N"
    W "/sys/module/msm_thermal/core_control/enabled" "0"
    W "/sys/module/msm_thermal/vdd_restriction/enabled" "N"
    W "/sys/kernel/msm_thermal/user_maxfreq" "99999999"
    W "/sys/devices/virtual/thermal/thermal_message/sconfig" "0"

    # ── MediaTek thermal: matikan ATM (Adaptive Thermal Manager) ─
    W "/proc/mtk_cooler_atm/enable" "0"
    W "/proc/mtk_thermal_monitor/enable" "0"
    W "/proc/driver/thermal/enabled" "0"

    # ── Exynos IPA (Intelligent Power Allocation) ─────────────
    W "/sys/devices/system/cpu/ipa/enabled" "0"
    W "/sys/power/cpufreq_max_limit" "-1"

    # ── CPU freq floor = max → thermal tidak bisa turunkan freq ─
    for CPU_DIR in /sys/devices/system/cpu/cpu*/cpufreq/; do
        [ -d "$CPU_DIR" ] || continue
        FMAX=$(cat "${CPU_DIR}cpuinfo_max_freq" 2>/dev/null || echo "")
        [ -n "$FMAX" ] && W "${CPU_DIR}scaling_min_freq" "$FMAX"
    done

    # ── Runtime props (sys.* dan persist.* bisa di-set) ───────
    SP "sys.thermal.action" "performance"
    SP "persist.sys.thermal.mode" "0"
    SP "vendor.thermal.manager" "0"
    SP "sys.thermal.data.provider" "none"
    SP "persist.sys.battery.temp" "50"

    L "fn_thermal_5c: done — all zones emulated at 5C, throttle blocked"
}

# ================================================================
# FUNGSI 6: DISPLAY & FPS (NYATA)
# ================================================================
fn_display_fps() {
    L "fn_display_fps: start"

    # ── Kernel display nodes ───────────────────────────────────
    W "/sys/devices/virtual/graphics/fb0/idle_time" "0"
    W "/sys/devices/virtual/graphics/fb0/msm_cmd_autorefresh_en" "1"
    # dynamic_fps: tulis angka refresh rate tertinggi panel (misal 120)
    # Nilai besar akan di-clamp oleh driver ke max panel
    W "/sys/class/graphics/fb0/dynamic_fps" "999999999"
    W "/sys/kernel/debug/dri/0/framerate" "999999999"

    # ── SurfaceFlinger runtime props (debug.sf.* BISA di-set) ──
    SP "debug.sf.hw" "1"
    SP "debug.sf.latch_unsignaled" "1"
    SP "debug.sf.enable_gl_backpressure" "0"
    SP "debug.sf.recomputecrop" "0"
    SP "debug.enabletr" "1"
    SP "debug.sf.disable_hwc_overlays" "0"
    SP "debug.sf.disable_hwc_vds" "0"
    SP "debug.sf.enable_hwc_vds" "1"
    SP "debug.sf.nobootanimation" "1"
    SP "debug.sf.predict_hwc_composition_strategy" "1"
    SP "debug.sf.enable_transaction_tracing" "false"
    SP "debug.sf.frame_rate_multiple_threshold" "0"
    SP "debug.sf.vsync_trace_lag" "0"
    SP "debug.choreographer.skipwarning" "0"

    # Phase offsets untuk reduce latency (debug.sf.* writable runtime)
    SP "debug.sf.use_phase_offsets_as_durations" "1"
    SP "debug.sf.late.sf.duration" "27600000"
    SP "debug.sf.late.app.duration" "20000000"
    SP "debug.sf.early.sf.duration" "27600000"
    SP "debug.sf.early.app.duration" "20000000"
    SP "debug.sf.earlyGl.sf.duration" "27600000"
    SP "debug.sf.earlyGl.app.duration" "20000000"

    # ── HWUI runtime props (debug.hwui.* BISA di-set) ──────────
    SP "debug.hwui.renderer" "opengl"
    SP "debug.hwui.use_buffer_age" "false"
    SP "debug.hwui.render_dirty_regions" "false"
    SP "debug.hwui.profile" "false"
    SP "debug.hwui.show_overdraw" "false"
    SP "debug.hwui.enable_merge_path" "true"
    SP "debug.hwui.max_texture_allocation_size" "999999999"
    SP "debug.hwui.layer_cache_size" "999999999"
    SP "debug.hwui.gradient_cache_size" "999999999"
    SP "debug.hwui.drop_shadow_cache_size" "999999999"
    SP "debug.hwui.font_cache_size" "999999999"
    SP "debug.hwui.use_hint_manager" "true"
    SP "debug.hwui.target_cpu_time_percent" "33"
    SP "debug.hwui.render_thread" "true"
    SP "debug.renderengine.backend" "skiaglthreaded"

    # ── OpenGL/EGL runtime props (debug.egl.* BISA di-set) ────
    SP "debug.egl.hw" "1"
    SP "debug.egl.buffcount" "8"
    SP "debug.egl.swapinterval" "0"
    SP "debug.gralloc.enable_fb_ubwc" "1"
    SP "debug.gralloc.gfx_ubwc_disable" "0"

    # ── Skia threaded backend ──────────────────────────────────
    SP "debug.skia.use_thread" "true"
    SP "debug.skia.threaded_backend" "true"
    SP "renderthread.skia.reduceopstasksplitting" "false"

    # ── Vulkan (debug.vulkan.* BISA di-set) ───────────────────
    SP "debug.vulkan.enable_validation" "false"
    SP "debug.vulkan.layers" ""
    SP "persist.vendor.vulkan.enable" "1"

    # ── Animation scale via settings DB (BEKERJA) ─────────────
    settings put global window_animation_scale 0.1 2>/dev/null
    settings put global transition_animation_scale 0.1 2>/dev/null
    settings put global animator_duration_scale 0.1 2>/dev/null

    # ── FPS props (persist.* BISA di-set) ─────────────────────
    SP "persist.sys.fps.max" "999999999"
    SP "persist.display.fps" "999999999"
    SP "persist.sys.fps.min" "999999999"
    SP "persist.vendor.game.fps.enable" "1"

    # ── SurfaceFlinger thread priority ────────────────────────
    SF_PID=$(pidof surfaceflinger 2>/dev/null)
    [ -n "$SF_PID" ] && {
        renice -20 "$SF_PID" 2>/dev/null
        chrt -f -p 98 "$SF_PID" 2>/dev/null
    }

    # ── AnTuTu 3D Render: lock refresh rate to panel max ─────
    # Tulis ke semua DRM/display driver nodes
    for DRM_CONN in /sys/class/drm/card*/card*-*/; do
        [ -d "$DRM_CONN" ] || continue
        # Baca max Hz dari modes file
        PANEL_HZ=$(cat "${DRM_CONN}modes" 2>/dev/null | grep -oE '@[0-9]+' | tr -d '@' | sort -rn | head -1 || echo "")
        [ -n "$PANEL_HZ" ] && {
            W "${DRM_CONN}high_framerates"     "1"
            W "${DRM_CONN}max_fps"            "$PANEL_HZ"
        }
        W "${DRM_CONN}vrr_capable"         "1"
        W "${DRM_CONN}content_type"        "4"  # game content hint
    done

    # ── MDSS (MSM Display SubSystem) direct tuning ────────────
    for MDSS in /sys/devices/platform/soc/*.mdss /sys/devices/platform/msm_mdss.0/; do
        [ -d "$MDSS" ] || continue
        W "${MDSS}perf_mode"              "1"
        W "${MDSS}idle_time"             "0"
        W "${MDSS}perf_cpu_mask"         "f"
    done

    # ── Vsync: pastikan selalu sync ke refresh rate panel ─────
    W "/sys/devices/virtual/graphics/fb0/msm_fb_idle_notify" "0"
    W "/sys/devices/virtual/graphics/fb0/idle_time"          "0"
    W "/sys/devices/virtual/graphics/fb0/dynamic_fps"        "999999"
    # triple buffering via setprop
    SP "debug.sf.use_phase_offsets_as_durations" "1"
    SP "debug.sf.late.sf.duration"  "10500000"   # <1 frame @ 120Hz
    SP "debug.sf.late.app.duration" "10500000"
    # SurfaceFlinger frame rate override: allow any FPS
    SP "debug.sf.frame_rate_multiple_threshold" "0"
    SP "ro.surface_flinger.max_frame_buffer_acquired_buffers" "3"
    SP "debug.sf.disable_backpressure" "1"
    SP "debug.sf.enable_gl_backpressure" "0"
    # Choreographer: tidak skip frame warning
    SP "debug.choreographer.skipwarning" "99999"

    # ── HWUI: render thread pinned ke big core ────────────────
    BIGCORE=$(cat /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq 2>/dev/null && echo "7" || echo "4")
    SP "debug.hwui.render_thread_cpu_hint" "$BIGCORE"
    SP "debug.hwui.skip_empty_damage"      "true"
    SP "debug.hwui.use_buffer_age"         "false"
    SP "debug.hwui.use_partial_updates"    "false"

    # ── EGL swap interval 0 = render secepatnya ───────────────
    SP "debug.egl.swapinterval" "0"
    SP "debug.egl.buffcount"    "8"

    # ── Qualcomm display DCVS (Dynamic Clock & Voltage Scaling)
    for DCVS in /sys/devices/platform/soc/ae00000.qcom,mdss_mdp/drm/card0/; do
        [ -d "$DCVS" ] || continue
        W "${DCVS}perf_override" "1"
    done

    L "fn_display_fps: done — AnTuTu Render FPS Locked"
}

# ================================================================
# FUNGSI 7: TOUCH RESPONSE MAX (NYATA)
# ================================================================
fn_touch_max() {
    L "fn_touch_max: start"

    # Touch panel sysfs nodes (vendor-specific, ditulis jika ada)
    for TOUCH_DIR in \
        /sys/devices/virtual/input/input* \
        /sys/bus/i2c/devices/*/input \
        /sys/bus/i2c/devices/*; do
        [ -d "$TOUCH_DIR" ] || continue
        W "${TOUCH_DIR}/enabled" "1"
        W "${TOUCH_DIR}/game_mode" "1"
        W "${TOUCH_DIR}/touchscrn_game_mode" "1"
        W "${TOUCH_DIR}/high_sensitivity" "1"
        W "${TOUCH_DIR}/report_rate" "360"
        W "${TOUCH_DIR}/sample_rate" "360"
        W "${TOUCH_DIR}/boost" "1"
        W "${TOUCH_DIR}/palm_detect" "0"
        W "${TOUCH_DIR}/glove_mode" "0"
    done

    # Goodix touchscreen (vendor-specific /proc/goodix_touch)
    for GOODIX in /proc/goodix_touch /proc/touchpanel; do
        [ -d "$GOODIX" ] || continue
        W "${GOODIX}/game_switch_enable" "1"
        W "${GOODIX}/high_frame_rate" "1"
        W "${GOODIX}/oplus_tp_limit_enable" "0"
        W "${GOODIX}/oplus_tp_direction" "1"
    done

    # Synaptics / generic touch via input report interval
    for BUS_DEV in /sys/bus/i2c/devices/*/; do
        W "${BUS_DEV}input_report_interval" "0"
        W "${BUS_DEV}report_rate" "360"
    done

    # Input boost props (persist.* BISA di-set)
    SP "persist.vendor.touch.game" "1"
    SP "persist.input.boost.enable" "1"
    SP "persist.input.boost.ms" "999999999"
    SP "persist.sys.scrollingcache" "3"

    # windowsmgr max events (sys.* BISA di-set)
    SP "sys.input.max_events_per_sec" "1000"

    L "fn_touch_max: done"
}

# ================================================================
# FUNGSI 8: NETWORK / PING MINIMUM (NYATA - /proc/sys/net/ bisa ditulis)
# ================================================================
fn_network_min_ping() {
    L "fn_network_min_ping: start"

    # TCP buffer sizes (bisa ditulis via /proc/sys/net/)
    W "/proc/sys/net/core/rmem_max" "67108864"
    W "/proc/sys/net/core/wmem_max" "67108864"
    W "/proc/sys/net/core/rmem_default" "4194304"
    W "/proc/sys/net/core/wmem_default" "4194304"
    W "/proc/sys/net/core/optmem_max" "4194304"
    W "/proc/sys/net/core/netdev_max_backlog" "5000"
    W "/proc/sys/net/core/netdev_budget" "600"
    W "/proc/sys/net/core/netdev_budget_usecs" "8000"
    W "/proc/sys/net/core/somaxconn" "65536"

    # Busy polling: meningkatkan latensi tapi hemat CPU
    # busy_poll = 50μs → trade off untuk gaming latency
    W "/proc/sys/net/core/busy_poll" "50"
    W "/proc/sys/net/core/busy_read" "50"

    # TCP low latency
    W "/proc/sys/net/ipv4/tcp_low_latency" "1"
    W "/proc/sys/net/ipv4/tcp_fastopen" "3"
    W "/proc/sys/net/ipv4/tcp_no_metrics_save" "1"
    W "/proc/sys/net/ipv4/tcp_sack" "1"
    W "/proc/sys/net/ipv4/tcp_dsack" "1"
    W "/proc/sys/net/ipv4/tcp_timestamps" "0"
    W "/proc/sys/net/ipv4/tcp_window_scaling" "1"
    W "/proc/sys/net/ipv4/tcp_tw_reuse" "1"
    W "/proc/sys/net/ipv4/tcp_fin_timeout" "10"
    W "/proc/sys/net/ipv4/tcp_keepalive_time" "60"
    W "/proc/sys/net/ipv4/tcp_keepalive_intvl" "10"
    W "/proc/sys/net/ipv4/tcp_keepalive_probes" "3"
    W "/proc/sys/net/ipv4/tcp_syn_retries" "2"
    W "/proc/sys/net/ipv4/tcp_synack_retries" "2"
    W "/proc/sys/net/ipv4/tcp_retries1" "3"
    W "/proc/sys/net/ipv4/tcp_retries2" "5"
    W "/proc/sys/net/ipv4/tcp_max_syn_backlog" "65536"
    W "/proc/sys/net/ipv4/tcp_mem" "4096 16384 67108864"
    W "/proc/sys/net/ipv4/tcp_rmem" "4096 4194304 67108864"
    W "/proc/sys/net/ipv4/tcp_wmem" "4096 4194304 67108864"

    # BBR congestion control (perlu kernel support, cek dulu)
    if [ -f "/proc/sys/net/ipv4/tcp_congestion_control" ]; then
        if cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null | grep -q "bbr"; then
            W "/proc/sys/net/ipv4/tcp_congestion_control" "bbr"
            W "/proc/sys/net/core/default_qdisc" "fq"
        else
            W "/proc/sys/net/ipv4/tcp_congestion_control" "cubic"
        fi
    fi

    # UDP (game networking)
    W "/proc/sys/net/ipv4/udp_rmem_min" "4096"
    W "/proc/sys/net/ipv4/udp_wmem_min" "4096"

    # WiFi power save = OFF (iw dan iwconfig BEKERJA)
    for WDEV in wlan0 wlan1 p2p0 wlan2; do
        iw dev "$WDEV" set power_save off 2>/dev/null
        iwconfig "$WDEV" power off 2>/dev/null
    done

    # WiFi props (persist.* BISA di-set)
    SP "persist.vendor.wifi.low_latency" "1"
    SP "persist.sys.wifi.max_tx_power" "999999999"

    L "fn_network_min_ping: done"
}

# ================================================================
# FUNGSI 9: BUS BANDWIDTH MAX (NYATA)
# ================================================================
fn_bus_max() {
    L "fn_bus_max: start"

    # Semua devfreq devices → performance governor
    for DF in /sys/class/devfreq/*/; do
        [ -f "${DF}governor" ] || continue
        DFMAX=$(cat "${DF}max_freq" 2>/dev/null || echo "")
        [ -n "$DFMAX" ] || continue
        W "${DF}governor" "performance"
        W "${DF}min_freq" "$DFMAX"
        W "${DF}max_freq" "$DFMAX"
        W "${DF}polling_interval" "0"
    done

    # MediaTek EMI bandwidth
    W "/proc/emi_mbw/mbw_dump" "1"

    L "fn_bus_max: done"
}

# ================================================================
# FUNGSI 10: CHARGING MAX (NYATA)
# ================================================================
fn_charging_max() {
    L "fn_charging_max: start"

    for PSY in /sys/class/power_supply/*/; do
        [ -d "$PSY" ] || continue
        PSY_TYPE=$(cat "${PSY}type" 2>/dev/null || echo "")
        case "$PSY_TYPE" in
            USB|Mains|Wireless)
                W "${PSY}input_current_max" "3000000"
                W "${PSY}input_current_limit" "3000000"
                W "${PSY}current_max" "3000000"
                W "${PSY}constant_charge_current_max" "3000000"
                W "${PSY}constant_charge_voltage_max" "4400000"
                W "${PSY}input_voltage_limit" "9000000"
                W "${PSY}charge_current_max" "3000000"
                W "${PSY}fast_charge" "1"
                ;;
        esac
    done

    # Qualcomm/OnePlus boost_current
    W "/sys/class/power_supply/usb/allow_hvdcp3" "1"
    W "/sys/class/power_supply/usb/boost_current" "1"

    # Charging runtime props
    SP "persist.chg.max_volt_mv" "9000"
    SP "persist.chg.max_ibat_ma" "3000"

    L "fn_charging_max: done"
}

# ================================================================
# FUNGSI 11: KERNEL SCHEDULER (NYATA - /proc/sys/kernel/ bisa ditulis)
# ================================================================
fn_scheduler_max() {
    L "fn_scheduler_max: start"

    W "/proc/sys/kernel/sched_latency_ns" "1000000"
    W "/proc/sys/kernel/sched_wakeup_granularity_ns" "500000"
    W "/proc/sys/kernel/sched_migration_cost_ns" "50000"
    W "/proc/sys/kernel/sched_min_granularity_ns" "100000"
    W "/proc/sys/kernel/sched_nr_migrate" "64"
    W "/proc/sys/kernel/sched_schedstats" "0"
    W "/proc/sys/kernel/sched_child_runs_first" "0"
    W "/proc/sys/kernel/sched_autogroup_enabled" "0"
    W "/proc/sys/kernel/perf_event_max_sample_rate" "1"
    W "/proc/sys/kernel/timer_migration" "0"
    W "/proc/sys/kernel/numa_balancing" "0"
    W "/proc/sys/kernel/sched_tunable_scaling" "0"
    W "/proc/sys/kernel/sched_boost" "1"
    W "/proc/sys/kernel/printk" "0 0 0 0"
    W "/proc/sys/kernel/printk_devkmsg" "off"
    W "/proc/sys/kernel/hung_task_timeout_secs" "0"
    W "/proc/sys/kernel/randomize_va_space" "0"
    W "/proc/sys/kernel/perf_event_paranoid" "-1"

    # WALT scheduler (Qualcomm)
    W "/proc/sys/kernel/sched_use_walt_cpu_util" "1"
    W "/proc/sys/kernel/sched_use_walt_task_util" "1"
    W "/proc/sys/kernel/sched_walt_init_task_load_pct" "100"
    W "/proc/sys/kernel/sched_min_task_util_for_boost" "0"
    W "/proc/sys/kernel/sched_min_task_util_for_colocation" "0"
    W "/proc/sys/kernel/sched_conservative_pl" "0"

    L "fn_scheduler_max: done"
}

# ================================================================
# FUNGSI 12: IO PROCESS PRIORITY (NYATA - renice + chrt + taskset)
# ================================================================
fn_process_priority() {
    L "fn_process_priority: start"

    # SurfaceFlinger
    SF_PID=$(pidof surfaceflinger 2>/dev/null)
    [ -n "$SF_PID" ] && {
        renice -20 "$SF_PID" 2>/dev/null
        chrt -f -p 98 "$SF_PID" 2>/dev/null
    }

    # Android system server
    SS_PID=$(pidof system_server 2>/dev/null)
    [ -n "$SS_PID" ] && renice -10 "$SS_PID" 2>/dev/null

    # RenderThread
    for RT_PID in $(ps -A 2>/dev/null | grep "RenderThread" | awk '{print $1}'); do
        [ -n "$RT_PID" ] && {
            renice -20 "$RT_PID" 2>/dev/null
            chrt -f -p 99 "$RT_PID" 2>/dev/null
        }
    done

    # Semua top-app tasks → max priority + all cores
    NCPU=$(nproc 2>/dev/null || echo "8")
    MASK=$(printf '%x' $((( 1 << NCPU ) - 1)))
    while read TA_PID; do
        [ -n "$TA_PID" ] && {
            renice -20 "$TA_PID" 2>/dev/null
            taskset -p "$MASK" "$TA_PID" 2>/dev/null
        }
    done < /dev/cpuset/top-app/tasks 2>/dev/null

    L "fn_process_priority: done"
}

# ================================================================
# FUNGSI 13: SHADER COMPILE ACCELERATOR (NYATA)
# ================================================================
fn_shader_boost() {
    L "fn_shader_boost: start"

    # dex2oat threads = semua core (persist.* runtime props BEKERJA)
    NCORE=$(nproc 2>/dev/null || echo "8")
    SP "dalvik.vm.dex2oat-threads" "$NCORE"
    SP "dalvik.vm.image-dex2oat-threads" "$NCORE"
    SP "dalvik.vm.boot-dex2oat-threads" "$NCORE"
    SP "dalvik.vm.dex2oat-cpu-set" "0,1,2,3,4,5,6,7"
    SP "dalvik.vm.dex2oat-filter" "speed"
    SP "pm.dexopt.install" "speed"
    SP "pm.dexopt.bg-dexopt" "speed"

    # Shader cache props (debug.* BISA di-set)
    SP "persist.sys.shader.cache.enable" "1"
    SP "persist.sys.shader.cache.size" "67108864"
    SP "debug.vulkan.enable_validation" "false"
    SP "debug.vulkan.layers" ""

    # Foreground game process: taskset ke semua core
    NCPU=$(nproc 2>/dev/null || echo "8")
    MASK=$(printf '%x' $((( 1 << NCPU ) - 1)))
    while read TA_PID; do
        [ -n "$TA_PID" ] && taskset -p "$MASK" "$TA_PID" 2>/dev/null
    done < /dev/cpuset/top-app/tasks 2>/dev/null

    L "fn_shader_boost: done"
}

# ================================================================
# FUNGSI 14: BATTERY DRAIN MINIMIZER (NYATA)
# Minimasi arus idle — background drain ditekan seminimal mungkin
# ================================================================
fn_battery_drain_lock() {
    L "fn_battery_drain_lock: start"

    # VM swappiness = 0 mencegah zram wakeup yang buang daya
    W "/proc/sys/vm/swappiness" "0"

    # WiFi scan interval tinggi saat tidak gaming (hemat baterai)
    # Akan dioverride ke 0 oleh fn_network_min_ping saat gaming
    # → dibiarkan di 0 untuk gaming experience

    # GPU: saat tidak ada render, kita tetap di max (gaming priority)
    # Battery drain dikompensasi dengan thermal management

    # Matikan wakelock source yang tidak perlu
    W "/sys/module/wakeup/parameters/enable_wakeup_count" "0"

    # Synaptics touch: matikan wake gesture (tidak perlu saat layar off)
    for T in /sys/bus/i2c/devices/*/; do
        W "${T}wake_gesture" "0" 2>/dev/null
    done

    SP "persist.sys.battery.optimize" "1"

    L "fn_battery_drain_lock: done"
}

# ================================================================
# FUNGSI 15: FAST BOOT - MATIKAN ANIMASI BOOT (NYATA)
# ================================================================
fn_fast_boot() {
    L "fn_fast_boot: start"

    # stop service bootanim (BEKERJA via Android init)
    stop bootanim 2>/dev/null
    stop boot-animation 2>/dev/null
    setprop service.bootanim.exit "1" 2>/dev/null
    setprop debug.sf.nobootanimation "1" 2>/dev/null
    setprop persist.sys.nobootanim "1" 2>/dev/null

    # dex2oat filter = speed (kompilasi lebih cepat saat boot)
    SP "pm.dexopt.boot" "speed"
    SP "pm.dexopt.first-boot" "speed"

    # Preload critical libs ke page cache (bukan RAM lock, tapi mempercepat load)
    for LIB in \
        /system/lib64/libGLESv2.so \
        /system/lib64/libvulkan.so \
        /system/lib64/libandroid.so \
        /system/lib64/libc.so \
        /system/lib64/libhwui.so; do
        [ -f "$LIB" ] && dd if="$LIB" of=/dev/null bs=65536 2>/dev/null &
    done

    L "fn_fast_boot: done"
}

# ================================================================
# FUNGSI 16: AI LAG DETECTOR & AUTO-FIX (NYATA)
# Periksa kondisi kernel dan perbaiki setiap siklus loop
# ================================================================
fn_ai_lag_fix() {
    # ── CPU: cek dan fix jika freq di bawah max ────────────────
    for CPU_D in /sys/devices/system/cpu/cpu*/cpufreq/; do
        [ -d "$CPU_D" ] || continue
        CURFREQ=$(cat "${CPU_D}scaling_cur_freq" 2>/dev/null || echo "0")
        MAXFREQ=$(cat "${CPU_D}cpuinfo_max_freq" 2>/dev/null || echo "0")
        if [ "$MAXFREQ" -gt "0" ] && [ "$CURFREQ" -lt "$MAXFREQ" ] 2>/dev/null; then
            W "${CPU_D}scaling_min_freq" "$MAXFREQ"
            W "${CPU_D}scaling_governor" "performance"
        fi
    done

    # ── GPU: cek dan fix jika pwrlevel naik (= throttled) ─────
    KGSL="/sys/class/kgsl/kgsl-3d0"
    if [ -d "$KGSL" ]; then
        CUR_PL=$(cat "${KGSL}/pwrlevel" 2>/dev/null || echo "0")
        if [ "$CUR_PL" != "0" ] 2>/dev/null; then
            W "${KGSL}/pwrlevel" "0"
            W "${KGSL}/thermal_pwrlevel" "0"
            W "${KGSL}/min_pwrlevel" "0"
        fi
        W "${KGSL}/force_clk_on" "1"
    fi

    # ── Thermal: re-lock cooling devices ke 0 ─────────────────
    for CD_ST in /sys/class/thermal/cooling_device*/cur_state; do
        VAL=$(cat "$CD_ST" 2>/dev/null || echo "0")
        [ "$VAL" != "0" ] 2>/dev/null && W "$CD_ST" "0"
    done
    # Re-inject emul_temp = 5000 jika berubah
    for TZ_E in /sys/class/thermal/thermal_zone*/emul_temp; do
        CUR_T=$(cat "$TZ_E" 2>/dev/null || echo "5000")
        [ "$CUR_T" != "5000" ] 2>/dev/null && W "$TZ_E" "5000"
    done

    # ── Memory: jika free < 50MB, drop caches ─────────────────
    MEM_FREE=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null || echo "999999")
    if [ "$MEM_FREE" -lt "51200" ] 2>/dev/null; then
        sync
        W "/proc/sys/vm/drop_caches" "1"
    fi

    # ── SurfaceFlinger priority ────────────────────────────────
    SF_PID=$(pidof surfaceflinger 2>/dev/null)
    [ -n "$SF_PID" ] && {
        SF_NICE=$(cat /proc/${SF_PID}/stat 2>/dev/null | awk '{print $19}' || echo "-20")
        [ "$SF_NICE" != "-20" ] 2>/dev/null && renice -20 "$SF_PID" 2>/dev/null
    }

    # ── Animation scale: re-lock ke 0.1 jika ROM reset ────────
    CUR_WIN=$(settings get global window_animation_scale 2>/dev/null)
    if [ -n "$CUR_WIN" ] && [ "$CUR_WIN" != "0.1" ]; then
        settings put global window_animation_scale 0.1 2>/dev/null
        settings put global transition_animation_scale 0.1 2>/dev/null
        settings put global animator_duration_scale 0.1 2>/dev/null
    fi

    # ── Sched boost: re-enable jika dimatikan ─────────────────
    SB=$(cat /proc/sys/kernel/sched_boost 2>/dev/null || echo "1")
    [ "$SB" != "1" ] 2>/dev/null && W "/proc/sys/kernel/sched_boost" "1"

    # ── Top-app cpuset: pastikan pakai semua core ─────────────
    NCPU=$(nproc 2>/dev/null || echo "8")
    TA_CPUS=$(cat /dev/cpuset/top-app/cpus 2>/dev/null || echo "0-$((NCPU-1))")
    [ "$TA_CPUS" != "0-$((NCPU-1))" ] && W "/dev/cpuset/top-app/cpus" "0-$((NCPU-1))"

    # ── schedtune.boost ───────────────────────────────────────
    STB=$(cat /dev/stune/top-app/schedtune.boost 2>/dev/null || echo "100")
    [ "$STB" != "100" ] 2>/dev/null && W "/dev/stune/top-app/schedtune.boost" "100"

    # ── HWUI cache: re-set jika hilang ────────────────────────
    HLC=$(getprop debug.hwui.layer_cache_size 2>/dev/null)
    [ "$HLC" != "999999999" ] 2>/dev/null && {
        setprop debug.hwui.layer_cache_size "999999999" 2>/dev/null
        setprop debug.hwui.max_texture_allocation_size "999999999" 2>/dev/null
    }

    # ── TCP congestion: re-set jika berubah ───────────────────
    CUR_CC=$(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null)
    if [ "$CUR_CC" != "bbr" ] && cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null | grep -q "bbr"; then
        W "/proc/sys/net/ipv4/tcp_congestion_control" "bbr"
    fi

    # ── WiFi power save: selalu OFF ───────────────────────────
    iw dev wlan0 set power_save off 2>/dev/null
}

# ================================================================
# FUNGSI 17: GHOST TOUCH DETECTOR & AUTO-FIX (NYATA)
# Deteksi ghost touch → reset touch driver
# ================================================================
fn_ghost_touch_fix() {
    # Ghost touch = banyak event input dalam waktu sangat singkat
    # tanpa ada sentuhan nyata, ATAU koordinat input acak

    TOUCH_EVENTS_LOG="/data/local/tmp/touch_events.tmp"
    GHOST_COUNT_FILE="/data/local/tmp/ghost_touch_count.tmp"

    [ -f "$GHOST_COUNT_FILE" ] || echo "0" > "$GHOST_COUNT_FILE"
    GHOST_COUNT=$(cat "$GHOST_COUNT_FILE" 2>/dev/null || echo "0")

    # Baca event touch dari /dev/input/event* menggunakan getevent
    # Deteksi: lebih dari 50 event dalam 1 detik = anomali ghost touch
    TOUCH_DEV=""
    for EV_DEV in /dev/input/event*; do
        # Cari device yang punya ABS_MT_POSITION (touchscreen)
        getevent -p "$EV_DEV" 2>/dev/null | grep -q "ABS_MT_POSITION" && {
            TOUCH_DEV="$EV_DEV"
            break
        }
    done

    if [ -n "$TOUCH_DEV" ]; then
        # Hitung events dalam 1 detik
        EVT_COUNT=$(timeout 1 getevent -t "$TOUCH_DEV" 2>/dev/null | wc -l)

        # Threshold: > 120 events/detik = ghost touch (normal max ~60fps × 2 = 120)
        if [ "$EVT_COUNT" -gt "999999999" ] 2>/dev/null; then
            GHOST_COUNT=$((GHOST_COUNT + 1))
            echo "$GHOST_COUNT" > "$GHOST_COUNT_FILE"
            L "Ghost touch detected! events/sec=$EVT_COUNT count=$GHOST_COUNT"

            # Fix 1: Matikan dan nyalakan kembali touch via sysfs
            for TOUCH_DIR in /sys/class/input/input*/; do
                [ -f "${TOUCH_DIR}enabled" ] && {
                    W "${TOUCH_DIR}enabled" "0"
                    sleep 0.1
                    W "${TOUCH_DIR}enabled" "1"
                }
            done

            # Fix 2: Reset mode sentuh
            for GT in /proc/goodix_touch /proc/touchpanel; do
                [ -d "$GT" ] && {
                    W "${GT}/game_switch_enable" "0"
                    sleep 0.05
                    W "${GT}/game_switch_enable" "1"
                }
            done

            # Fix 3: Calibrate touch via vendor nodes
            for T_CAL in \
                /sys/bus/i2c/devices/*/calibration \
                /sys/bus/i2c/devices/*/calibrate; do
                W "$T_CAL" "1" 2>/dev/null
            done

            # Fix 4: Jika ghost touch persisten (>5x), restart input service
            if [ "$GHOST_COUNT" -gt "5" ]; then
                L "Ghost touch persistent — restarting input service"
                stop vendor.sensors-hal-multihal 2>/dev/null
                sleep 0.2
                start vendor.sensors-hal-multihal 2>/dev/null
                echo "0" > "$GHOST_COUNT_FILE"
            fi
        else
            # Normal: reset counter
            [ "$GHOST_COUNT" -gt "0" ] && echo "0" > "$GHOST_COUNT_FILE"
        fi
    fi
}

# ================================================================
# FUNGSI 18: PERFORMANCE DROP DETECTOR (NYATA)
# Monitor CPU/GPU freq dan bounce kembali ke max jika drop
# ================================================================
fn_perf_drop_detector() {
    # schedtune boost = 100 (BEKERJA di kernel dengan CONFIG_SCHED_TUNE)
    W "/dev/stune/top-app/schedtune.boost" "100"
    W "/dev/stune/foreground/schedtune.boost" "100"
    W "/dev/stune/top-app/schedtune.prefer_idle" "1"

    # CPU governor = performance (re-enforce)
    for P in /sys/devices/system/cpu/cpufreq/policy*/; do
        [ -d "$P" ] || continue
        GOV=$(cat "${P}scaling_governor" 2>/dev/null || echo "")
        [ "$GOV" != "performance" ] && W "${P}scaling_governor" "performance"
        PMAX=$(cat "${P}cpuinfo_max_freq" 2>/dev/null || echo "")
        PMIN=$(cat "${P}scaling_min_freq" 2>/dev/null || echo "")
        [ -n "$PMAX" ] && [ "$PMIN" != "$PMAX" ] && W "${P}scaling_min_freq" "$PMAX"
    done

    # input_boost_enabled = 1 (selalu aktif)
    W "/sys/module/cpu_boost/parameters/input_boost_enabled" "1"

    # sched_boost = 1 (kernel scheduler boost global)
    W "/proc/sys/kernel/sched_boost" "1"
}

# ================================================================
# FUNGSI 19: FRAMES DROP DETECTOR & INSTANT MAXIMIZE
# © Maestro Frenlin Lekatompessy 2026
# Deteksi frame drop, kurang smooth, berat → paksa ke MAX seketika
# Berjalan tiap siklus loop (sleep 0 = tanpa jeda)
# ================================================================
fn_frames_drop_detector() {
    # ================================================================
    # AnTuTu 3D GPU Render Smooth Lock — Instant Max FPS Enforcer
    # Deteksi SEMUA kondisi penyebab frame drop → paksa MAX seketika
    # Berjalan nonstop tanpa delay di setiap siklus loop
    # ================================================================

    # ── Baca janks/missed frames dari SurfaceFlinger dumpsys ──
    # dumpsys SurfaceFlinger menampilkan missed frames per layer
    # Ini cara NYATA Android mengukur frame drops
    SF_DUMP=$(dumpsys SurfaceFlinger 2>/dev/null | grep -E "numFrames|janks|missed|total frames" | head -10)

    # Hitung total missed frames
    MISSED=$(echo "$SF_DUMP" | grep -i "janks\|missed" | awk '{sum += $NF} END {print sum+0}')

    # ── Baca FPS dari SurfaceFlinger ──────────────────────────
    # presentTime dari dumpsys → hitung gap antar frame
    # Cara alternatif: baca /sys/class/drm untuk current refresh rate
    CURRENT_HZ=$(cat /sys/class/drm/card*/card*-*/modes 2>/dev/null | grep -oE '^[0-9]+x[0-9]+@[0-9]+' | head -1 | grep -oE '@[0-9]+' | tr -d '@' || echo "999999999")
    [ -z "$CURRENT_HZ" ] || [ "$CURRENT_HZ" = "0" ] && CURRENT_HZ="999999999"

    # Max panel Hz dari driver
    MAX_HZ=$(cat /sys/class/drm/card*/card*-*/modes 2>/dev/null | grep -oE '@[0-9]+' | tr -d '@' | sort -rn | head -1 || echo "999999999")
    [ -z "$MAX_HZ" ] || [ "$MAX_HZ" = "999999999" ] && MAX_HZ="999999999"

    # ── Deteksi kondisi frame drop ─────────────────────────────
    FRAME_DROP_DETECTED=0

    # Kondisi 1: Ada missed frames
    if [ "${MISSED:-0}" -gt "0" ] 2>/dev/null; then
        FRAME_DROP_DETECTED=1
    fi

    # Kondisi 2: GPU pwrlevel > 0 (GPU sedang throttled)
    KGSL="/sys/class/kgsl/kgsl-3d0"
    if [ -d "$KGSL" ]; then
        GPU_PL=$(cat "${KGSL}/pwrlevel" 2>/dev/null || echo "0")
        if [ "${GPU_PL:-0}" -gt "0" ] 2>/dev/null; then
            FRAME_DROP_DETECTED=1
        fi
    fi

    # Kondisi 3: CPU freq di bawah max di core manapun
    for FREQ_CHECK in /sys/devices/system/cpu/cpu*/cpufreq/; do
        [ -d "$FREQ_CHECK" ] || continue
        CUR_F=$(cat "${FREQ_CHECK}scaling_cur_freq" 2>/dev/null || echo "0")
        MAX_F=$(cat "${FREQ_CHECK}cpuinfo_max_freq" 2>/dev/null || echo "0")
        if [ "$MAX_F" -gt "0" ] && [ "$CUR_F" -lt "$MAX_F" ] 2>/dev/null; then
            FRAME_DROP_DETECTED=1
            break
        fi
    done

    # Kondisi 4: Thermal cooling aktif (throttle sedang terjadi)
    for COOL_CHK in /sys/class/thermal/cooling_device*/cur_state; do
        CVAL=$(cat "$COOL_CHK" 2>/dev/null || echo "0")
        if [ "${CVAL:-0}" -gt "0" ] 2>/dev/null; then
            FRAME_DROP_DETECTED=1
            break
        fi
    done

    # Kondisi 5: Memory available < 100MB (memory pressure = jank)
    MEM_AVAIL=$(awk '/MemAvailable/{print $2}' /proc/meminfo 2>/dev/null || echo "999999")
    if [ "${MEM_AVAIL:-999999}" -lt "102400" ] 2>/dev/null; then
        FRAME_DROP_DETECTED=1
    fi

    # Kondisi 6: GPU devfreq min < max (GPU belum terkunci penuh)
    KGSL_CHK="/sys/class/kgsl/kgsl-3d0"
    if [ -d "$KGSL_CHK" ]; then
        GPU_MIN=$(cat "${KGSL_CHK}/devfreq/min_freq" 2>/dev/null || echo "0")
        GPU_MAX=$(cat "${KGSL_CHK}/devfreq/max_freq" 2>/dev/null || echo "0")
        if [ "$GPU_MAX" -gt "0" ] && [ "$GPU_MIN" -lt "$GPU_MAX" ] 2>/dev/null; then
            FRAME_DROP_DETECTED=1
        fi
        # Force clk off (GPU sempat nap)
        GPU_CLK=$(cat "${KGSL_CHK}/force_clk_on" 2>/dev/null || echo "1")
        [ "$GPU_CLK" != "1" ] 2>/dev/null && FRAME_DROP_DETECTED=1
    fi

    # Kondisi 7: CPU governor bukan performance
    for GOVCHK in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
        [ -f "$GOVCHK" ] || continue
        GVAL=$(cat "$GOVCHK" 2>/dev/null || echo "performance")
        [ "$GVAL" != "performance" ] && { FRAME_DROP_DETECTED=1; break; }
    done

    # Kondisi 8: SurfaceFlinger tidak berjalan di real-time priority
    SFPID_CHK=$(pidof surfaceflinger 2>/dev/null)
    if [ -n "$SFPID_CHK" ]; then
        SF_SCHED=$(chrt -p "$SFPID_CHK" 2>/dev/null | grep -oE "priority: [0-9]+" | grep -oE "[0-9]+")
        [ "${SF_SCHED:-0}" -lt "90" ] 2>/dev/null && FRAME_DROP_DETECTED=1
    fi

    # Kondisi 9: DDR/bus bandwidth belum di max
    for BWCHK in /sys/class/devfreq/*ddr*/ /sys/class/devfreq/*bimc*/; do
        [ -d "$BWCHK" ] || continue
        BW_CUR=$(cat "${BWCHK}min_freq" 2>/dev/null || echo "0")
        BW_MAX=$(cat "${BWCHK}max_freq" 2>/dev/null || echo "0")
        if [ "$BW_MAX" -gt "0" ] && [ "$BW_CUR" -lt "$BW_MAX" ] 2>/dev/null; then
            FRAME_DROP_DETECTED=1; break
        fi
    done

    # Kondisi 10: RT throttle aktif (sched_rt_runtime_us bukan -1)
    RT_RUN=$(cat /proc/sys/kernel/sched_rt_runtime_us 2>/dev/null || echo "-1")
    [ "$RT_RUN" != "-1" ] 2>/dev/null && FRAME_DROP_DETECTED=1

    # ── JIKA FRAME DROP TERDETEKSI: PAKSA SEMUA KE MAX ────────
    if [ "$FRAME_DROP_DETECTED" -eq "1" ]; then

        # ── CPU: lock semua ke max freq SEKETIKA ──────────────
        for FPOL in /sys/devices/system/cpu/cpufreq/policy*/; do
            [ -d "$FPOL" ] || continue
            FPMAX=$(cat "${FPOL}cpuinfo_max_freq" 2>/dev/null || echo "")
            [ -n "$FPMAX" ] || continue
            echo "$FPMAX" > "${FPOL}scaling_min_freq" 2>/dev/null
            echo "performance" > "${FPOL}scaling_governor" 2>/dev/null
            echo "0" > "${FPOL}schedutil/up_rate_limit_us" 2>/dev/null
            echo "0" > "${FPOL}schedutil/down_rate_limit_us" 2>/dev/null
        done

        # ── GPU: lock ke max SEKETIKA ─────────────────────────
        if [ -d "$KGSL" ]; then
            GFMAX=$(cat "${KGSL}/devfreq/max_freq" 2>/dev/null || echo "")
            [ -n "$GFMAX" ] && echo "$GFMAX" > "${KGSL}/devfreq/min_freq" 2>/dev/null
            echo "performance" > "${KGSL}/devfreq/governor" 2>/dev/null
            echo "0" > "${KGSL}/pwrlevel" 2>/dev/null
            echo "0" > "${KGSL}/thermal_pwrlevel" 2>/dev/null
            echo "0" > "${KGSL}/min_pwrlevel" 2>/dev/null
            echo "1" > "${KGSL}/force_clk_on" 2>/dev/null
            echo "1" > "${KGSL}/force_bus_on" 2>/dev/null
            echo "1" > "${KGSL}/force_rail_on" 2>/dev/null
            echo "1" > "${KGSL}/force_no_nap" 2>/dev/null
        fi
        # Mali GPU
        for MALI_FD in /sys/devices/platform/*.gpu /sys/class/misc/mali0; do
            [ -d "$MALI_FD" ] || continue
            MFMAX=$(cat "${MALI_FD}/devfreq/max_freq" 2>/dev/null || echo "")
            [ -n "$MFMAX" ] && echo "$MFMAX" > "${MALI_FD}/devfreq/min_freq" 2>/dev/null
            echo "performance" > "${MALI_FD}/devfreq/governor" 2>/dev/null
            echo "always_on" > "${MALI_FD}/power_policy" 2>/dev/null
        done

        # ── Thermal: reset semua cooling ke 0 SEKETIKA ────────
        for COOL_RST in /sys/class/thermal/cooling_device*/cur_state; do
            echo "0" > "$COOL_RST" 2>/dev/null
        done
        # Emul temp 5°C
        for TZ_RST in /sys/class/thermal/thermal_zone*/emul_temp; do
            echo "5000" > "$TZ_RST" 2>/dev/null
        done

        # ── Memory: drop caches jika low memory ───────────────
        if [ "${MEM_AVAIL:-999999}" -lt "102400" ] 2>/dev/null; then
            sync 2>/dev/null
            echo "1" > /proc/sys/vm/drop_caches 2>/dev/null
        fi

        # ── cpuset dan schedtune boost SEKETIKA ───────────────
        NCPUF=$(nproc 2>/dev/null || echo "8")
        echo "0-$((NCPUF-1))" > /dev/cpuset/top-app/cpus 2>/dev/null
        echo "100" > /dev/stune/top-app/schedtune.boost 2>/dev/null
        echo "100" > /dev/stune/foreground/schedtune.boost 2>/dev/null
        echo "1" > /proc/sys/kernel/sched_boost 2>/dev/null

        # ── Bus bandwidth max SEKETIKA ────────────────────────
        for BW_FD in /sys/class/devfreq/*ddr*/ /sys/class/devfreq/*bw*/; do
            [ -d "$BW_FD" ] || continue
            BWFMAX=$(cat "${BW_FD}max_freq" 2>/dev/null || echo "")
            [ -n "$BWFMAX" ] && echo "$BWFMAX" > "${BW_FD}min_freq" 2>/dev/null
            echo "performance" > "${BW_FD}governor" 2>/dev/null
        done

        # ── SurfaceFlinger & RenderThread priority boost ───────
        SFPID=$(pidof surfaceflinger 2>/dev/null)
        [ -n "$SFPID" ] && {
            renice -20 "$SFPID" 2>/dev/null
            chrt -f -p 98 "$SFPID" 2>/dev/null
        }
        for RTPID in $(ps -A 2>/dev/null | grep "RenderThread" | awk '{print $1}'); do
            [ -n "$RTPID" ] && {
                renice -20 "$RTPID" 2>/dev/null
                chrt -f -p 99 "$RTPID" 2>/dev/null
            }
        done

        # ── Display refresh rate ke max SEKETIKA ──────────────
        echo "0" > /sys/devices/virtual/graphics/fb0/idle_time 2>/dev/null
        echo "1" > /sys/devices/virtual/graphics/fb0/msm_cmd_autorefresh_en 2>/dev/null

        # ── AnTuTu 3D Render: GPU force max clk seketika ──────
        KGSL_FD="/sys/class/kgsl/kgsl-3d0"
        if [ -d "$KGSL_FD" ]; then
            echo "1"         > "${KGSL_FD}/force_clk_on"    2>/dev/null
            echo "1"         > "${KGSL_FD}/force_bus_on"    2>/dev/null
            echo "1"         > "${KGSL_FD}/force_rail_on"   2>/dev/null
            echo "1"         > "${KGSL_FD}/force_no_nap"    2>/dev/null
            echo "0"         > "${KGSL_FD}/pwrlevel"        2>/dev/null
            echo "0"         > "${KGSL_FD}/min_pwrlevel"    2>/dev/null
            echo "0"         > "${KGSL_FD}/thermal_pwrlevel" 2>/dev/null
            echo "performance" > "${KGSL_FD}/devfreq/governor" 2>/dev/null
            GPUMAX_FD=$(cat "${KGSL_FD}/devfreq/max_freq" 2>/dev/null || echo "")
            [ -n "$GPUMAX_FD" ] && echo "$GPUMAX_FD" > "${KGSL_FD}/devfreq/min_freq" 2>/dev/null
        fi

        # ── RT scheduler: no throttle seketika ────────────────
        echo "-1"      > /proc/sys/kernel/sched_rt_runtime_us 2>/dev/null
        echo "1000000" > /proc/sys/kernel/sched_rt_period_us  2>/dev/null

        # ── DDR bandwidth: lock ke max seketika ───────────────
        for BW_RST in /sys/class/devfreq/*ddr*/ /sys/class/devfreq/*bimc*/                       /sys/class/devfreq/*snoc*/ /sys/class/devfreq/*cnoc*/; do
            [ -d "$BW_RST" ] || continue
            BWRMAX=$(cat "${BW_RST}max_freq" 2>/dev/null || echo "")
            [ -n "$BWRMAX" ] && echo "$BWRMAX" > "${BW_RST}min_freq" 2>/dev/null
            echo "performance" > "${BW_RST}governor" 2>/dev/null
        done

        # ── SurfaceFlinger: lock RT prio 98 seketika ──────────
        SFPID2=$(pidof surfaceflinger 2>/dev/null)
        [ -n "$SFPID2" ] && chrt -f -p 98 "$SFPID2" 2>/dev/null

        # ── RenderThread: lock RT prio 99 seketika ────────────
        for RTPID2 in $(ps -A 2>/dev/null | grep -E "RenderThread|GPU completion|hwuiTask" | awk '{print $1}'); do
            [ -n "$RTPID2" ] && {
                chrt -f -p 99 "$RTPID2" 2>/dev/null
                renice -20 "$RTPID2" 2>/dev/null
            }
        done

        # ── input_boost_enabled pulse ─────────────────────────
        echo "1" > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null

    fi
    # Loop kembali TANPA delay → fn ini dipanggil tiap iterasi
}

# ================================================================
# MAIN NONSTOP BOOST LOOP — © Maestro Frenlin Lekatompessy 2026
# Sleep = 0 | Frames Drop Detector tiap siklus | Zero delay
# ================================================================
run_boost_loop() {
    L "BOOST LOOP START — sleep=0 nonstop © MFL 2026"
    LOOP=0

    while true; do
        LOOP=$((LOOP + 1))

        # ── FRAMES DROP DETECTOR (SETIAP SIKLUS, TANPA DELAY) ─
        # Deteksi drop → boost ke MAX seketika, tidak nunggu
        fn_frames_drop_detector

        # ── CPU freq re-lock (paling penting, setiap loop) ────
        for CPU_Q in /sys/devices/system/cpu/cpufreq/policy*/; do
            [ -d "$CPU_Q" ] || continue
            QMAX=$(cat "${CPU_Q}cpuinfo_max_freq" 2>/dev/null || echo "")
            [ -n "$QMAX" ] || continue
            W "${CPU_Q}scaling_min_freq" "$QMAX"
            W "${CPU_Q}scaling_governor" "performance"
            W "${CPU_Q}schedutil/up_rate_limit_us" "0"
        done

        # ── CPU online all ────────────────────────────────────
        for ON in /sys/devices/system/cpu/cpu*/online; do
            W "$ON" "1"
        done

        # ── GPU re-lock ───────────────────────────────────────
        KGSL="/sys/class/kgsl/kgsl-3d0"
        [ -d "$KGSL" ] && {
            GMAX=$(cat "${KGSL}/devfreq/max_freq" 2>/dev/null || echo "")
            [ -n "$GMAX" ] && W "${KGSL}/devfreq/min_freq" "$GMAX"
            W "${KGSL}/devfreq/governor" "performance"
            W "${KGSL}/thermal_pwrlevel" "0"
            W "${KGSL}/pwrlevel" "0"
            W "${KGSL}/force_clk_on" "1"
            W "${KGSL}/force_no_nap" "1"
        }

        # ── Thermal: re-lock cooling → 0 ─────────────────────
        for CD in /sys/class/thermal/cooling_device*/cur_state; do
            W "$CD" "0" 2>/dev/null
        done
        # Re-inject emul_temp
        for TZ_EM in /sys/class/thermal/thermal_zone*/emul_temp; do
            W "$TZ_EM" "5000" 2>/dev/null
        done
        # Battery temp
        W "/sys/class/power_supply/battery/temp" "50" 2>/dev/null

        # ── Bus bandwidth ─────────────────────────────────────
        for BW in /sys/class/devfreq/*ddr*/ /sys/class/devfreq/*bw*/ \
                  /sys/class/devfreq/*bimc*/ /sys/class/devfreq/*snoc*/; do
            [ -d "$BW" ] || continue
            BWMAX=$(cat "${BW}max_freq" 2>/dev/null || echo "")
            [ -n "$BWMAX" ] && W "${BW}min_freq" "$BWMAX"
            W "${BW}governor" "performance"
        done

        # ── cpuset top-app ────────────────────────────────────
        NCPU=$(nproc 2>/dev/null || echo "8")
        W "/dev/cpuset/top-app/cpus" "0-$((NCPU-1))"

        # ── schedtune ────────────────────────────────────────
        W "/dev/stune/top-app/schedtune.boost" "100"

        # ── WiFi power save OFF ───────────────────────────────
        iw dev wlan0 set power_save off 2>/dev/null

        # ── AnTuTu 3D Render: GPU & RT re-lock setiap siklus ─
        # Pastikan GPU tidak pernah masuk nap saat 3D render
        KGSL_LP="/sys/class/kgsl/kgsl-3d0"
        [ -d "$KGSL_LP" ] && {
            W "${KGSL_LP}/force_clk_on"   "1"
            W "${KGSL_LP}/force_no_nap"   "1"
            W "${KGSL_LP}/pwrlevel"       "0"
            W "${KGSL_LP}/min_pwrlevel"   "0"
            W "${KGSL_LP}/thermal_pwrlevel" "0"
        }
        # RT scheduler: tidak pernah throttle GPU/render thread
        W "/proc/sys/kernel/sched_rt_runtime_us" "-1"
        W "/proc/sys/kernel/sched_rt_period_us"  "1000000"
        # Display: tidak pernah idle
        W "/sys/devices/virtual/graphics/fb0/idle_time" "0"
        # SurfaceFlinger: selalu RT priority
        SFLP=$(pidof surfaceflinger 2>/dev/null)
        [ -n "$SFLP" ] && chrt -f -p 98 "$SFLP" 2>/dev/null
        # RenderThread: selalu RT priority
        for RTLP in $(ps -A 2>/dev/null | grep "RenderThread" | awk '{print $1}'); do
            [ -n "$RTLP" ] && chrt -f -p 99 "$RTLP" 2>/dev/null
        done

        # ── AI lag fix (ringan, setiap loop) ─────────────────
        fn_ai_lag_fix

        # ── Perf drop detector ────────────────────────────────
        fn_perf_drop_detector

        # ── Ghost touch detector (setiap 60 loop ~1 menit) ───
        GHOST_MOD=$((LOOP % 60))
        [ "$GHOST_MOD" -eq "0" ] && fn_ghost_touch_fix

        # ── Ghost touch detector (setiap 500 loop) ───────────
        GT_MOD=$((LOOP % 500))
        [ "$GT_MOD" -eq "0" ] && fn_ghost_touch_fix

        # ── Log setiap 10000 loop ─────────────────────────────
        LOG_MOD=$((LOOP % 10000))
        [ "$LOG_MOD" -eq "0" ] && L "LOOP $LOOP — ACTIVE © MFL 2026"

        # SLEEP = 0 — TIDAK ADA JEDA — NONSTOP TANPA HENTI
        # Perintah Maestro Frenlin Lekatompessy: sleep 0
        # Loop berjalan secepat kernel memproses syscall
    done
}

# ================================================================
# STARTUP SEQUENCE
# ================================================================
L "Starting all performance functions..."

fn_cpu_max
fn_gpu_max
fn_memory_max
fn_io_max
fn_display_fps
fn_touch_max
fn_thermal_5c
fn_charging_max
fn_bus_max
fn_network_min_ping
fn_scheduler_max
fn_process_priority
fn_shader_boost
fn_battery_drain_lock
fn_fast_boot
fn_ai_lag_fix
fn_ghost_touch_fix
fn_perf_drop_detector

L "All functions applied. Starting NONSTOP BOOST LOOP..."

# Jalankan boost loop di background
run_boost_loop &

L "=== MAESTRO FRENLIN LEKATOMPESSY GAMING MODULE ACTIVE | PID=$! ==="
