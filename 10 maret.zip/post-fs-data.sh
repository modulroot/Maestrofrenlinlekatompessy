#!/system/bin/sh
# ============================================================
# ⚡ ULTRA GAMING KERNEL BOOST - post-fs-data.sh ⚡
# Runs EARLY in boot process - before service.sh
# ============================================================

MODDIR=${0%/*}

# Early write helper
ew() { [ -e "$1" ] && echo "$2" > "$1" 2>/dev/null; }

# Early CPU boost
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/; do
    FMAX=$(cat "${cpu}cpuinfo_max_freq" 2>/dev/null || echo "")
    [ -n "$FMAX" ] && {
        ew "${cpu}scaling_governor" "performance"
        ew "${cpu}scaling_min_freq" "$FMAX"
    }
done

# Early GPU boost
ew "/sys/class/kgsl/kgsl-3d0/devfreq/governor" "performance"
ew "/sys/class/kgsl/kgsl-3d0/force_clk_on" "1"

# Early IO
for BLK in /sys/block/*/queue/; do
    ew "${BLK}scheduler" "none"
    ew "${BLK}read_ahead_kb" "4096"
done

# Early VM
ew "/proc/sys/vm/swappiness" "0"
ew "/proc/sys/vm/vfs_cache_pressure" "0"

# Early thermal trip = max
for TZ in /sys/class/thermal/thermal_zone*/trip_point_0_temp; do
    ew "$TZ" "99999"
done

# Early animation = 0
setprop persist.animation.scale "0"
setprop debug.egl.hw "1"
